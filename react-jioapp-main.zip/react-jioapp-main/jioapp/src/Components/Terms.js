import React from "react";
// import { Link } from "react-router-dom";

export default function Location(){
    return(
        <div>
            Terms and conditions page.
        </div>
    )
}